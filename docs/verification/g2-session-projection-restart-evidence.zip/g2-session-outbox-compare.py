import json
import re
import zipfile
from pathlib import Path

root = Path('D:/Temp/paralls-g0-b3-ingress-20261109')
current = Path('D:/Temp/g2-session-restart-baseline-20261110')
prior = Path('D:/Temp/g2-session-outbox-projection-baseline')
with zipfile.ZipFile(root / 'docs/verification/g0-939c6746/full-4c641876.zip') as archive:
    baseline = json.loads(archive.read('paralls-g0-4c641876-run1/results.json'))
new = json.loads((current / 'results.json').read_text(encoding='utf-8'))
previous = json.loads((prior / 'results.json').read_text(encoding='utf-8'))
def norm(value):
    value = value.replace('\\', '/')
    value = re.sub(r'pytest-\d+', 'pytest-N', value)
    return re.sub(r'(?i)(cancel scope )(?:at )?(?:0x)?[0-9a-f]+', r'\g<1>ID', value)
def compare(label, old):
    a = {x['test_name']: x for x in old['tests']}
    b = {x['test_name']: x for x in new['tests']}
    missing = sorted(a.keys() - b.keys())
    changed = [k for k in a.keys() & b.keys() if a[k]['phases'] != b[k]['phases'] or a[k]['outcome'] != b[k]['outcome']]
    signatures = lambda data: {(x['test_name'], x['phase'], x['error_type']): x for x in data['failures']}
    af, bf = signatures(old), signatures(new)
    stacks = [k for k in af.keys() & bf.keys() if norm(af[k]['stack']) != norm(bf[k]['stack'])]
    print(label, 'missing', missing, 'changed', changed, 'added node count', len(b.keys()-a.keys()))
    print(label, 'removed failures', sorted(af.keys()-bf.keys()), 'added failures', sorted(bf.keys()-af.keys()), 'stack differences', stacks)
print('counts', new['collected_count'], new['counts'], 'collection errors', new['collection_errors'])
compare('G0', baseline)
compare('previous', previous)
a = json.loads((prior / 'environment.json').read_text(encoding='utf-8'))
b = json.loads((current / 'environment.json').read_text(encoding='utf-8'))
for key in ('python', 'executable', 'os', 'packages_sha256', 'dependency_files', 'pytest_env'):
    print(key, 'same', a[key] == b[key])
print('source_unchanged', b.get('source_unchanged'), 'head stable', b.get('head') == b.get('head_after'), 'status stable', b.get('git_status_before') == b.get('git_status_after'))
