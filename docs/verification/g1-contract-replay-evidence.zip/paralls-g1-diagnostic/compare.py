import json
import sys
import zipfile
from pathlib import Path

root = Path("D:/Temp/paralls-g0-b3-ingress-20261109")
with zipfile.ZipFile(root / "docs/verification/g0-939c6746/full-4c641876.zip") as archive:
    baseline = json.loads(archive.read("paralls-g0-4c641876-run1/results.json"))
run = json.loads((Path(sys.argv[1]) / "results.json").read_text(encoding="utf-8"))
old = {item["test_name"]: item for item in baseline["tests"]}
new = {item["test_name"]: item for item in run["tests"]}
print("counts:", baseline["counts"], run["counts"])
print("missing:", sorted(old.keys() - new.keys()))
print("new count:", len(new.keys() - old.keys()))
print("new nonpassing:", [(key, new[key]["outcome"]) for key in sorted(new.keys() - old.keys()) if new[key]["outcome"] != "passed"])
print("outcome differences:", [(key, old[key]["outcome"], new[key]["outcome"]) for key in sorted(old.keys() & new.keys()) if old[key]["outcome"] != new[key]["outcome"]])
old_failures = {(item["test_name"], item["phase"], item["error_type"]): item for item in baseline["failures"]}
new_failures = {(item["test_name"], item["phase"], item["error_type"]): item for item in run["failures"]}
print("removed failures:", sorted(old_failures.keys() - new_failures.keys()))
print("added failures:", sorted(new_failures.keys() - old_failures.keys()))
print("changed stacks:", [key for key in sorted(old_failures.keys() & new_failures.keys()) if old_failures[key]["stack_hash"] != new_failures[key]["stack_hash"]])
print("collection errors:", run["collection_errors"])
