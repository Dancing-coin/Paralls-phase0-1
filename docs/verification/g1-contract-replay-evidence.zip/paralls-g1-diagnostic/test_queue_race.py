import asyncio
from threading import Event

import pytest
from fastapi.testclient import TestClient

from test_status_application_lifecycle import application
from test_world_admin_cadence_revocation_application import _verifier


@pytest.mark.asyncio
async def test_unrelated_submission_can_release_test_barrier(application, monkeypatch):
    main, start, advance = application
    await start()
    await advance(86400)
    execution = main.runtime_execution
    driver = main._population_runtime_driver
    payload = await asyncio.wrap_future(execution.submit(lambda: dict(
        world_ref=driver.world_runtime.mode.world_ref,
        cadence_id=driver.world_runtime.latest_confirmation.cadence_id,
        reason_code="administrator_cancelled", command_id="admin:diagnostic:1",
    )))
    monkeypatch.setattr(main, "time", lambda: 100)
    monkeypatch.setattr(main, "world_admin_credential_verifier", _verifier(expires_at=100))
    blocked, release, submitted, endpoint_submitted = Event(), Event(), Event(), Event()

    def hold_owner():
        blocked.set()
        assert release.wait(10)

    blocker = execution.submit(hold_owner)
    assert await asyncio.to_thread(blocked.wait, 5)
    original_submit = execution.submit

    def observe_submit(command):
        future = original_submit(command)
        submitted.set()
        if command.__qualname__ == "revoke_world_admin_cadence.<locals>.command":
            endpoint_submitted.set()
        return future

    monkeypatch.setattr(execution, "submit", observe_submit)
    execution.submit(lambda: None)
    assert await asyncio.to_thread(submitted.wait, 5)
    monkeypatch.setattr(main, "world_admin_credential_verifier",
                        _verifier(expires_at=100, principal_ref="principal:replacement"))
    client = TestClient(main.component_app, client=("127.0.0.1", 47224))
    response_task = asyncio.create_task(asyncio.to_thread(
        client.post, "/admin/cadence-revocations", json=payload,
        headers={"Authorization": "Bearer " + "a" * 40},
    ))
    try:
        assert await asyncio.to_thread(endpoint_submitted.wait, 5)
    finally:
        release.set()
    await asyncio.wrap_future(blocker)
    response = await asyncio.wait_for(response_task, 5)
    client.close()
    assert response.status_code == 200, response.text
    event = await asyncio.wrap_future(execution.submit(lambda: next(
        e for e in main.gameplay_event_store.read_events()
        if e.event_type == "population.cadence.revoked")))
    assert event.payload["authenticated_principal_ref"] == "principal:replacement"
